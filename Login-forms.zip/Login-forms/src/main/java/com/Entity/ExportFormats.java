package com.Entity;

public class ExportFormats {
	public ExportFormats() {
		super();
	}

	private String formats;

	public ExportFormats(String formats) {
		super();
		this.formats = formats;
	}

	public String getFormats() {
		return formats;
	}

	public void setFormats(String formats) {
		this.formats = formats;
	}

}
