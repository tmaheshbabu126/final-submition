package com.Controller;

import java.io.*;
import java.net.MalformedURLException;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.Entity.SearchDate;
import com.Entity.SearchKeyWords;
import com.Service.SearchDateImp;
import com.Service.SearchKeyWordsServiceImp;

@Controller

public class SearchController {
	
	
	
	// -----------check whether an element is present in an array---------------
	 private static boolean check(String[] children, String q)
	    {
	        // sort given array
	        Arrays.sort(children);
	 
	        // check if the specified element
	        // is present in the array or not
	        // using Binary Search method
	        int res = Arrays.binarySearch(children, q);
	 
	        boolean test = res > 0 ? true : false;
	 
	    return test;
	    }
	 //--------------------------------------------------------------------------
	
	
	

	@Autowired
	SearchKeyWordsServiceImp si;

	@Autowired
	SearchDateImp sdi;

	
	@RequestMapping("/search")
	@ResponseBody
	public ModelAndView
	thymeleafView( @RequestParam String q ,Map<String, Object> model,Model model1,RedirectAttributes redirectAttributes, HttpServletResponse httpResponse) throws IOException, ParseException {



		System.out.println(q);



		SearchKeyWords s = new SearchKeyWords((long) 0,q,1);//changed from 0 to 1


		SearchKeyWords te1= si.addSearch(s);//sending the model obtained from client to service to process, for adding tenant

		int id = si.findByIdKey(q);

		System.out.println("the effective search id = "+id);


		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		String sd = dtf.format(now);


		Date date2=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse(sd);

		System.out.println(dtf.format(now));

		SearchDate sed= new SearchDate(0,date2,id);

		sdi.addDate(sed);

		ResponseEntity<SearchKeyWords> rt=new ResponseEntity<SearchKeyWords>(te1,HttpStatus.OK); //response to client
		//return rt;
		System.out.println(rt);
		
		//redirectAttributes.addFlashAttribute("search1","here the link will be coming in sc");
		
		// ------------------------added to check whether there is a match for the search
		
		
		 
				 File dir = new File("C:\\Users\\mahes\\Desktop\\Task-CG-Asha\\dummy files");
			      String[] children = dir.list();
			      
			      if (children == null) {
			         System.out.println("does not exist or is not a directory");
			      } else {
			    	  System.out.println("in file parsing");
			         for (int i = 0; i < children.length; i++) {
			            String filename = children[i];
			            System.out.println(filename);
			         }
			      }
			      
			   boolean fileFound =   check(children, q);
				// ---------------------------------------------------------
		
			   if(fileFound) {
		model1.addAttribute("search1", q);
		return new ModelAndView("SearchResult");
		}
			   else {
				   model1.addAttribute("search1", "There were no files found by your search");
					return new ModelAndView("noSearchFound");
			   }
		

	//	httpResponse.sendRedirect("/SearchResult");
	//	httpResponse.sendRedirect("/SearchResult");
		

		//return "redirect:/SearchResult";
		//return new ModelAndView("SearchResult");
//		httpResponse.sendRedirect("/index");
//
//		return "redirect:/index";
	}
	 
	
	@RequestMapping(value = "/result-view")
	public ResponseEntity<UrlResource> showEmployee(@RequestParam String filename,HttpServletRequest request, HttpServletResponse response, Model model1,RedirectAttributes redirectAttributes) throws IOException {
		final String fileBasePath = "C:\\Users\\mahes\\Desktop\\Task-CG-Asha\\dummy files\\";
		
		
		Path path = Paths.get(fileBasePath + filename);
		System.out.println(filename);
		UrlResource resource = null;
		try {
			resource = new UrlResource(path.toUri());
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok()
				.contentType(MediaType.parseMediaType("application/octet-stream"))
				.header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" +  ((UrlResource) resource).getFilename() + "\"")
				.body(resource);
		//return "SearchResult";
 
	}
	

	@RequestMapping(value = "/noSearchFound")
	public ModelAndView nosearchfound() {
		
		return new ModelAndView("noSearchFound");
		
	}
	
		

}
