package com.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class SearchResultController {
	

	
	  @RequestMapping(value = "/SearchResult") public String showEmployee( Model
	  model1,RedirectAttributes redirectAttributes) {
	  
			/*
			 * redirectAttributes.addFlashAttribute(
			 * "search1","here the link will be coming"); model1.addAttribute("search1",
			 * "here the link will be coming");
			 */
	  
	  return "SearchResult";
	  
	  }
	 

}
