package com;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;



public interface UsersRepository extends JpaRepository<Users, Integer>{
	
    @Query("SELECT u FROM Users u join u.roles r WHERE u.username = :username and r.roleName='USER'")
    public List<Users> findUser(@Param("username") String username);

    @Query("SELECT u FROM Users u join u.roles r WHERE u.username = :username and r.roleName='ADMIN'")
    public List<Users> findAdmin(@Param("username") String username);

    @Query(value =" select role_name from Role where role_id in (\r\n"
    		+ "    		select role_id from user_role where user_id in\r\n"
    		+ "    		(SELECT u.user_id FROM Users u where username = :username))", nativeQuery = true)
	public String findRoleByUsername(@Param("username") String username);


    
   

}