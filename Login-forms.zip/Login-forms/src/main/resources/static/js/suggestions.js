
console.log("Filename = ");
console.log(number);

let suggestions = number;
/*let suggestions =["Text File","Csv File", "xlsx File"];*/
console.log("the suggestions are");